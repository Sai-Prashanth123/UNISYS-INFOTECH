// This file is kept for backward compatibility
// The actual database connection is now in src/config/supabase.js
import { connectDB } from './supabase.js';
export default connectDB;
